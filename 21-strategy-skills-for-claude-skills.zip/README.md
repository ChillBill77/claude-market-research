# 21 Consulting-Style Strategy Skills for Claude

A downloadable pack of 21 standalone Claude skills for strategy work, grouped into six
engagement domains: diagnose, map markets, choose strategy, build execution, govern value,
and communicate. Each skill runs a named method and works on its own or as part of a full engagement.

## What's inside

### Diagnosis & Framing
1. **Situation Assessment** (situation-assessment) - Returns a fact-based picture of where the business actually is, the real question to answer, and what is and isn't yet known.
2. **Growth Barriers** (growth-barriers) - Finds the single binding constraint on growth rather than the loudest complaint.
3. **Assumption Audit** (assumption-audit) - Surfaces the unstated beliefs a strategy rests on and stress-tests the ones that matter.

### Market & Competitive Intelligence
4. **Market Mapping** (market-mapping) - Sizes the market and finds where attractive, under-served space sits.
5. **Competitive Intel** (competitive-intel) - Models rival capabilities and the moves they are most likely to make next.
6. **Customer Segmentation** (customer-segmentation) - Produces decision-useful segments instead of generic personas.
7. **Profit Pool Analysis** (profit-pool-analysis) - Maps where the money actually sits along the value chain.

### Strategic Choice & Economics
8. **Strategic Options** (strategic-options) - Generates a real option set and reasons to a recommendation instead of advocating one answer.
9. **Pricing Strategy** (pricing-strategy) - Diagnoses pricing and produces a concrete pricing action plan.
10. **Business Case Builder** (business-case-builder) - Builds the economics behind a decision with the logic exposed.
11. **Portfolio Review** (portfolio-review) - Reallocates capital and attention across a portfolio on evidence, not inertia.

### Operating Model & Execution
12. **Operating Model Design** (operating-model-design) - Turns a strategy into the capabilities, structure, and decision rights to deliver it.
13. **Initiative Prioritizer** (initiative-prioritizer) - Reduces a long initiative list to the few that matter and sequences them.
14. **Transformation Roadmap** (transformation-roadmap) - Turns the plan into a phased roadmap with owners and the first 90 days.

### Risk, Performance & Value Governance
15. **War Gaming** (war-gaming) - Stress-tests a strategy against realistic opposition.
16. **Risk & Mitigation** (risk-mitigation) - Builds a board-ready risk view, not a generic risk list.
17. **KPI Architect** (kpi-architect) - Designs a metrics system that links daily work to strategic outcomes.
18. **Value Realization** (value-realization) - Makes sure the value a strategy promised is actually captured.

### Alignment & Executive Communication
19. **Stakeholder Alignment** (stakeholder-alignment) - Maps who must say yes and designs the plan to get them there.
20. **Narrative Builder** (narrative-builder) - Builds the recommendation story so it lands fast and survives scrutiny.
21. **Decision Memo** (decision-memo) - Turns the analysis into a one-page decision document an executive can act on.

## Install
1. Unzip this file.
2. Add the skill folders to a Claude Project as Project Knowledge, or copy them into `~/.claude/skills/`.
3. In a conversation, name the skill you want (for example, "Use the market-mapping skill"). Claude runs it with the framework already loaded.

Each skill is one folder with a single `SKILL.md`. Keep the whole set or pull out just the folders you need.
