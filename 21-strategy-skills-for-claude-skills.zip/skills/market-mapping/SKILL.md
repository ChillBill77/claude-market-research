---
name: market-mapping
description: Sizes the market and finds where attractive, under-served space sits.
---

# Market Mapping

## When to use
You need to size, segment, and map white space.

## What it does
Sizes the market and finds where attractive, under-served space sits.

## Method
1. Size TAM, SAM, and SOM with both top-down and bottom-up methods, then triangulate the gap between them.
2. Segment demand by jobs-to-be-done rather than by demographics alone.
3. Plot segments on a demand-strength vs supply-quality quadrant to expose white space.
4. Decompose growth by segment to see where the market itself is moving.

## Inputs
Market data, customer or category research, and any internal demand signal.

## Output format
A market map, a triangulated size, and a ranked set of where-to-play options.

## Example
Input: adjacent category. Output: SAM ~$1.2B, white space in the mid-market underserved by incumbents; two beachhead options.
