---
name: operating-model-design
description: Turns a strategy into the capabilities, structure, and decision rights to deliver it.
---

# Operating Model Design

## When to use
Strategy needs translation into how work gets done.

## What it does
Turns a strategy into the capabilities, structure, and decision rights to deliver it.

## Method
1. Derive the few capabilities the strategy actually requires.
2. Design the org and governance to own those capabilities.
3. Assign decision rights with a RACI or RAPID so accountability is unambiguous.
4. Map the core processes and the hand-offs most likely to break.

## Inputs
The chosen strategy and the current organization and processes.

## Output format
A target capability set, a governance design, and a decision-rights map.

## Example
Input: shift to solutions selling. Output: three new capabilities, a pod structure, and RAPID for pricing decisions.
