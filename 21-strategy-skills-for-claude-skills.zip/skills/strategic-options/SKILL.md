---
name: strategic-options
description: Generates a real option set and reasons to a recommendation instead of advocating one answer.
---

# Strategic Options

## When to use
You need alternatives before committing to a path.

## What it does
Generates a real option set and reasons to a recommendation instead of advocating one answer.

## Method
1. Generate options across horizons: optimize the core, expand adjacencies, and place transformational bets.
2. Define explicit decision criteria with weights (value, feasibility, risk, strategic fit).
3. Score each option against the criteria and show the trade-offs honestly.
4. Recommend, but name the conditions under which a different option wins.

## Inputs
The decision to be made, constraints, and the goals the choice must serve.

## Output format
An option set, a weighted criteria scorecard, and a conditional recommendation.

## Example
Input: declining core. Output: three options scored; 'expand adjacency' recommended unless capital is constrained, then 'optimize core.'
