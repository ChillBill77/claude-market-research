---
name: initiative-prioritizer
description: Reduces a long initiative list to the few that matter and sequences them.
---

# Initiative Prioritizer

## When to use
Too many initiatives compete for attention.

## What it does
Reduces a long initiative list to the few that matter and sequences them.

## Method
1. Plot every initiative on impact vs feasibility; size capital as bubble area.
2. Model capacity: how many can actually run in parallel given real constraints.
3. Sequence for dependencies and cash flow, not just attractiveness.
4. Write an explicit kill list with the reason each item was cut.

## Inputs
The candidate initiative list with rough impact, effort, and dependency notes.

## Output format
A ranked roadmap of the 3 to 5 that matter, plus a kill list.

## Example
Input: 14 initiatives. Output: 4 funded and sequenced; 10 killed with reasons.
