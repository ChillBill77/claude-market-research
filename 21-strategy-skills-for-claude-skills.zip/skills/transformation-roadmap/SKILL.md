---
name: transformation-roadmap
description: Turns the plan into a phased roadmap with owners and the first 90 days.
---

# Transformation Roadmap

## When to use
A strategy must become sequenced execution.

## What it does
Turns the plan into a phased roadmap with owners and the first 90 days.

## Method
1. Define phases with a clear objective and exit criteria for each.
2. Place initiatives into phases respecting dependencies and capacity.
3. Assign a single accountable owner and milestone per workstream.
4. Detail the first 90 days concretely so momentum starts immediately.

## Inputs
The prioritized initiatives, owners, and constraints.

## Output format
A phased roadmap with owners, milestones, risks, and a first-90-days plan.

## Example
Input: 4 initiatives. Output: 3 phases over 12 months; week-by-week first 90 days.
