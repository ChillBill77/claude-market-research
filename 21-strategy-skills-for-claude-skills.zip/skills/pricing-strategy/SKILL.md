---
name: pricing-strategy
description: Diagnoses pricing and produces a concrete pricing action plan.
---

# Pricing Strategy

## When to use
Pricing power, discounting, or monetization is unclear.

## What it does
Diagnoses pricing and produces a concrete pricing action plan.

## Method
1. Anchor to value: estimate the economic value the offer creates for each segment.
2. Probe willingness to pay with a Van Westendorp-style range where data allows.
3. Model price-volume sensitivity to find the margin-maximizing zone.
4. Translate into a pricing action plan: structure, fences, and discount discipline.

## Inputs
Current pricing, cost-to-serve, win/loss and discount data, and segment value.

## Output format
A pricing diagnosis and a sequenced pricing action plan.

## Example
Input: heavy discounting. Output: value gap in enterprise; move to tiered value pricing with a discount floor.
