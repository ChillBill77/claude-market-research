---
name: stakeholder-alignment
description: Maps who must say yes and designs the plan to get them there.
---

# Stakeholder Alignment

## When to use
The recommendation needs pre-wiring before the meeting.

## What it does
Maps who must say yes and designs the plan to get them there.

## Method
1. Map stakeholders on influence vs interest.
2. Write a short motivation analysis for each key player: what they want and what they fear.
3. Design an engagement card per swing vote: message, channel, and timing.
4. Pre-mortem the formal decision meeting and plan the pre-wire to defuse it.

## Inputs
The recommendation and the people whose support it needs.

## Output format
A stakeholder map and a sequenced engagement plan.

## Example
Input: contested reorg. Output: two swing votes identified; pre-wire sequence and tailored messages.
