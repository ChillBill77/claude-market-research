---
name: situation-assessment
description: Returns a fact-based picture of where the business actually is, the real question to answer, and what is and isn't yet known.
---

# Situation Assessment

## When to use
You need the factual baseline before choosing a direction.

## What it does
Returns a fact-based picture of where the business actually is, the real question to answer, and what is and isn't yet known.

## Method
1. Frame the ask with SCQA (Situation, Complication, Question, Answer-hypothesis) so the work is anchored to one decision question.
2. Triangulate performance across three lenses: financial (growth, margin, cash), market (share, demand, positioning), operational (throughput, quality, cost-to-serve).
3. Build a MECE issue tree from symptoms down to candidate root causes; mark each branch as fact, inference, or unknown.
4. Plot the headline findings on a 2x2 of impact vs certainty to separate the load-bearing issues from noise.

## Inputs
Business context, recent performance data, and the question leadership has asked.

## Output format
A one-page fact base, a momentum read, a ranked issues list, and the open questions that must be closed next.

## Example
Input: enterprise renewals declining. Output: churn concentrated in one onboarding cohort, not a pricing problem; two analyses named to confirm.
