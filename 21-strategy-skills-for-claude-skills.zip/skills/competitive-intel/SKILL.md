---
name: competitive-intel
description: Models rival capabilities and the moves they are most likely to make next.
---

# Competitive Intel

## When to use
You need to predict likely competitor moves.

## What it does
Models rival capabilities and the moves they are most likely to make next.

## Method
1. Run Porter's Five Forces to frame the structural pressure in the industry.
2. Define a three-ring competitive set: direct rivals, adjacent threats, and potential entrants.
3. Build a force-ranked capability matrix across the dimensions that decide the market.
4. Write a one-paragraph behavioral thesis per key rival, then pre-commit your response logic to their two most likely moves.

## Inputs
Competitor information, market structure, and your own capability picture.

## Output format
A rival move map, a capability matrix, and a pre-committed response plan.

## Example
Input: incumbent under pressure. Output: the #2 rival will most likely cut price in mid-market; pre-committed response set.
