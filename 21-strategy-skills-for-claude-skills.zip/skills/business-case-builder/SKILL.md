---
name: business-case-builder
description: Builds the economics behind a decision with the logic exposed.
---

# Business Case Builder

## When to use
A decision needs economics, sensitivities, and risks.

## What it does
Builds the economics behind a decision with the logic exposed.

## Method
1. Build a driver-based model: revenue, cost, capital, and timing drivers stated explicitly.
2. Compute NPV, IRR, and payback, and show the build, not just the answer.
3. Run sensitivities on the two or three drivers that move the result most.
4. List the key risks and what would have to be true for the case to hold.

## Inputs
The investment or initiative, cost and revenue drivers, and the time horizon.

## Output format
A business case with NPV/IRR, sensitivities, risks, and a clear decision logic.

## Example
Input: new product line. Output: NPV positive but swings on attach rate; case holds only above 18% attach.
