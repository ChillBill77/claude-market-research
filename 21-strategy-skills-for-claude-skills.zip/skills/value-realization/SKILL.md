---
name: value-realization
description: Makes sure the value a strategy promised is actually captured.
---

# Value Realization

## When to use
Benefits must be tracked after launch.

## What it does
Makes sure the value a strategy promised is actually captured.

## Method
1. Build a value ledger: every promised benefit, its size, and its owner.
2. Define how each benefit is measured and when it should land.
3. Set stage gates that release the next phase only when value is proven.
4. Govern: a cadence that reviews the ledger and reallocates if value stalls.

## Inputs
The business case benefits and the execution plan.

## Output format
A value ledger and a governance model that ties release to realized value.

## Example
Input: cost program. Output: $40M ledger with owners and gates; phase 2 funding gated on phase 1 proof.
