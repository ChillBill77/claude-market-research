---
name: kpi-architect
description: Designs a metrics system that links daily work to strategic outcomes.
---

# KPI Architect

## When to use
Metrics are noisy, lagging, or performative.

## What it does
Designs a metrics system that links daily work to strategic outcomes.

## Method
1. Define one north-star metric the strategy ultimately moves.
2. Decompose it into a MECE KPI tree down to operational drivers.
3. Set a three-layer metric set: outcome, driver, and health metrics.
4. Set action thresholds and stress-test each metric for proxy failure (how it could be gamed).

## Inputs
The strategic objective and the operational levers available.

## Output format
A decision-linked KPI system with thresholds and proxy-failure notes.

## Example
Input: vague 'engagement' goals. Output: north-star = activated accounts; KPI tree and thresholds that drive action.
