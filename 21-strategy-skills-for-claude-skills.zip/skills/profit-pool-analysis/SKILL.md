---
name: profit-pool-analysis
description: Maps where the money actually sits along the value chain.
---

# Profit Pool Analysis

## When to use
You need to know where value is created and captured.

## What it does
Maps where the money actually sits along the value chain.

## Method
1. Map the full value chain from input to end customer.
2. Estimate revenue and margin at each stage to build the profit pool.
3. Compare your position in the pool to where the deepest margins sit.
4. Identify migration: where the pool is shifting and what that implies for strategy.

## Inputs
Value-chain economics, your own margins, and any industry margin benchmarks you can source.

## Output format
A profit pool map and the strategic implications of where you sit versus where the value is.

## Example
Input: hardware-led business. Output: 70% of pool margin sits downstream in service; strategy should move toward attach.
