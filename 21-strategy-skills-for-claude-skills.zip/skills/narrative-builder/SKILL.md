---
name: narrative-builder
description: Builds the recommendation story so it lands fast and survives scrutiny.
---

# Narrative Builder

## When to use
You need the story to land in the first 60 seconds.

## What it does
Builds the recommendation story so it lands fast and survives scrutiny.

## Method
1. Structure with the Pyramid Principle: one governing thought, three supporting arguments, evidence under each.
2. Frame the opening with SCQA so the 'why now' is unavoidable.
3. Produce a Day-1 slide and four narrative lengths (30s, 2m, 10m, 60m).
4. Prepare the hostile questions and the answers before the room asks them.

## Inputs
The recommendation and the evidence behind it.

## Output format
A Pyramid-structured story, multiple lengths, and a hostile-question prep sheet.

## Example
Input: cost recommendation. Output: governing thought, 3 supports, and 8 hostile Qs answered.
