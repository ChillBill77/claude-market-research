---
name: assumption-audit
description: Surfaces the unstated beliefs a strategy rests on and stress-tests the ones that matter.
---

# Assumption Audit

## When to use
A strategy depends on beliefs that may be weak.

## What it does
Surfaces the unstated beliefs a strategy rests on and stress-tests the ones that matter.

## Method
1. Build an assumption register: list every belief the plan needs to be true.
2. Plot each on importance vs confidence; the high-importance, low-confidence quadrant is where the strategy is fragile.
3. Grade the evidence behind each assumption A to F.
4. Design a kill-shot test for the fragile ones, and write a short pre-mortem narrating how the strategy fails if they break.

## Inputs
The strategy or recommendation and the reasoning behind it.

## Output format
An assumption register, an importance-confidence map, evidence grades, and a test plan for the fragile assumptions.

## Example
Input: market-entry plan. Output: the whole case rests on an unproven channel-economics assumption graded D; one test named.
