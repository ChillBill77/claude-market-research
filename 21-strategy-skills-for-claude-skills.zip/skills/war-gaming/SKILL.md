---
name: war-gaming
description: Stress-tests a strategy against realistic opposition.
---

# War Gaming

## When to use
A strategy needs pressure-testing before launch.

## What it does
Stress-tests a strategy against realistic opposition.

## Method
1. Design the scenario and the question the game must answer.
2. Run a four-role team: Blue (you), Red (rivals), Yellow (customers/regulators), Control (referee).
3. Play three turns, forcing second and third-order effects each turn.
4. Register failure modes and pre-commit response thresholds.

## Inputs
The strategy under test and a picture of the relevant external actors.

## Output format
A scenario stress test, surfaced failure modes, and pre-committed response moves.

## Example
Input: aggressive launch. Output: Red price response breaks the case by turn 2; trigger and response pre-set.
