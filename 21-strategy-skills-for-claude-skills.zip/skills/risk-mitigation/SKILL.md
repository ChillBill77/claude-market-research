---
name: risk-mitigation
description: Builds a board-ready risk view, not a generic risk list.
---

# Risk & Mitigation

## When to use
Strategic risk needs an owner and response plan.

## What it does
Builds a board-ready risk view, not a generic risk list.

## Method
1. Build a risk register scoped to this strategy.
2. Score each risk on likelihood and impact and rank.
3. Assign an owner and a specific mitigation or contingency to the top risks.
4. Define leading indicators that fire before the risk materializes.

## Inputs
The strategy and the assumptions and dependencies it carries.

## Output format
A ranked risk register with owners, contingencies, and leading indicators.

## Example
Input: supplier-dependent plan. Output: single-source risk ranked #1; dual-source contingency and an early-warning metric.
