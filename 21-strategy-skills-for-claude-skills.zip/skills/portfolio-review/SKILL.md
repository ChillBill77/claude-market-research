---
name: portfolio-review
description: Reallocates capital and attention across a portfolio on evidence, not inertia.
---

# Portfolio Review

## When to use
You need to allocate resources across bets.

## What it does
Reallocates capital and attention across a portfolio on evidence, not inertia.

## Method
1. Plot each unit or bet on a nine-box attractiveness vs competitive-strength matrix.
2. Overlay capital consumed and returns to expose subsidies and starved winners.
3. Decide grow, hold, fix, or exit for each.
4. Reallocate: name what gets more, what gets less, and what stops.

## Inputs
Portfolio-level performance, capital allocation, and market attractiveness by unit.

## Output format
A portfolio diagnosis and explicit allocation choices.

## Example
Input: 8 business lines. Output: two starved winners get capital; one structurally weak line exits.
