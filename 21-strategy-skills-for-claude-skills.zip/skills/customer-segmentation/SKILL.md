---
name: customer-segmentation
description: Produces decision-useful segments instead of generic personas.
---

# Customer Segmentation

## When to use
You need sharper customer groups for strategy decisions.

## What it does
Produces decision-useful segments instead of generic personas.

## Method
1. Segment on needs and behavior (jobs-to-be-done), not just firmographics or demographics.
2. Test the cut for MECE: every customer lands in exactly one segment.
3. Score each segment on attractiveness (size, growth, willingness to pay) and right-to-win.
4. Rank segments and name the one or two to build the strategy around.

## Inputs
Customer data, usage or purchase behavior, and any qualitative research.

## Output format
A MECE segmentation, an attractiveness-vs-right-to-win view, and segment priorities.

## Example
Input: broad SMB base. Output: four needs-based segments; one high-WTP segment chosen as the wedge.
