---
name: decision-memo
description: Turns the analysis into a one-page decision document an executive can act on.
---

# Decision Memo

## When to use
An executive needs a clear recommendation in writing.

## What it does
Turns the analysis into a one-page decision document an executive can act on.

## Method
1. State the decision question precisely at the top.
2. Lay out the options considered and the criteria used.
3. Give the recommendation first, then the rationale (answer-first).
4. Close with the concrete next steps, owners, and the decision being asked for.

## Inputs
The recommendation, options, and supporting logic.

## Output format
A one-page decision memo with options, recommendation, rationale, and next steps.

## Example
Input: build-vs-buy. Output: one-page memo recommending buy, with rationale and the approval being requested.
