---
name: growth-barriers
description: Finds the single binding constraint on growth rather than the loudest complaint.
---

# Growth Barriers

## When to use
Growth is stuck and leadership is debating symptoms.

## What it does
Finds the single binding constraint on growth rather than the loudest complaint.

## Method
1. Decompose growth arithmetically into new, expansion, churn, and contraction.
2. Date the inflection point where the curve bent and align it to what changed.
3. Walk the full acquisition-to-retention funnel as a waterfall to locate the largest leak.
4. Read cohort retention curves for structural vs cyclical decay, then trace the cause with five-whys to a structural root.

## Inputs
Revenue and customer time series, funnel metrics, and cohort data if available.

## Output format
The binding constraint, the evidence behind it, and the next analysis that would confirm or kill it.

## Example
Input: 'why has growth slowed?' Output: expansion revenue collapsed post-onboarding change; retention, not acquisition, is the constraint.
